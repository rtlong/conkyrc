Mia's Scribblings ~
True Type Font for Windows

This font is free for all, but if used for commercial purposes, I would appreciate it if I could receive a copy of whatever it is used for. Or at the very least be acknowledged. Coz it is my font, y'know?

Anyways, enjoy!

Amelia McVinnie
princessmia89@gmail.com

p.s. If you are unsure how to install the font after unzipping this file, please go to this website http://support.microsoft.com/kb/314960.  It explains the steps much better than I ever could!